/*
  MCP2515.h - Library for Microchip MCP2515 CAN Controller
  
  Author: David Harding
  
  Created: 11/08/2010
  
  For further information see:
  
  http://ww1.microchip.com/downloads/en/DeviceDoc/21801e.pdf
  http://en.wikipedia.org/wiki/CAN_bus
*/

#ifndef MCP2515_h
#define MCP2515_h
#import <Arduino.h>

#include "MCP2515_defs.h"

class MCP2515
{
  public:
      // Constructor defining which pins to use for CS and INT
    MCP2515(uint8_t CS_Pin, uint8_t INT_Pin);
      
      // Overloaded initialization function
      int Init(int baud, uint8_t freq);
      int Init(int baud, uint8_t freq, uint8_t sjw);
      
      // Basic MCP2515 SPI Command Set
    void Reset();
    uint8_t Read(uint8_t address);
    void Read(uint8_t address, uint8_t data[], uint8_t bytes);
      Frame ReadBuffer(uint8_t buffer);
      void Write(uint8_t address, uint8_t data);
      void Write(uint8_t address, uint8_t data[], uint8_t bytes);
      void LoadBuffer(uint8_t buffer, Frame message);
      void SendBuffer(uint8_t buffers);
      uint8_t Status();
      uint8_t RXStatus();
      void BitModify(uint8_t address, uint8_t mask, uint8_t data);

      // Extra functions
      bool Interrupt(); // Expose state of INT pin
      bool Mode(uint8_t mode); // Returns TRUE if mode change successful
      
  private:
      bool _init(int baud, uint8_t freq, uint8_t sjw, bool autoBaud);
    // Pin variables
      uint8_t _CS;
      uint8_t _INT;
};

#endif